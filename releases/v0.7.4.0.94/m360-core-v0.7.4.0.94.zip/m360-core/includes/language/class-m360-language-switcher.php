<?php
if (!defined('ABSPATH')) { exit; }

final class M360_Language_Switcher
{
    private static bool $registered = false;

    public static function register(): void
    {
        if (self::$registered) { return; }
        self::$registered = true;
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets'], 20);
    }

    public static function register_shortcodes(): void
    {
        add_shortcode('m360_language_switcher', [self::class, 'render']);
        add_shortcode('m360_language_navigation', [self::class, 'render_navigation']);
    }

    public static function enqueue_assets(): void
    {
        if (is_admin()) { return; }

        $target = self::target(true);
        if (wp_style_is('m360-core-language-switcher', 'registered')) {
            wp_enqueue_style('m360-core-language-switcher');
        }
        if (!wp_script_is('m360-core-language-switcher', 'registered')) { return; }

        wp_enqueue_script('m360-core-language-switcher');
        wp_localize_script('m360-core-language-switcher', 'M360LanguageSwitcherConfig', [
            'available' => (bool) $target['available'],
            'singular' => is_singular(),
            'url' => (string) $target['url'],
            'locale' => (string) $target['locale'],
            'code' => (string) $target['code'],
            'flag' => (string) $target['flag'],
            'flagMarkup' => self::flag_markup((string) $target['code']),
            'title' => (string) $target['title'],
            'ariaLabel' => (string) $target['aria_label'],
        ]);
    }

    public static function render(array $atts = []): string
    {
        $target = self::target();
        if (!$target['available']) { return ''; }

        return '<div class="m360-floating-lang-toggle" data-m360-language-switcher="shortcode">'
            . '<a class="m360-lang-toggle" href="' . esc_url((string) $target['url']) . '"'
            . ' hreflang="' . esc_attr((string) $target['locale']) . '"'
            . ' title="' . esc_attr((string) $target['title']) . '"'
            . ' aria-label="' . esc_attr((string) $target['aria_label']) . '">'
            . '<span class="m360-lang-toggle__flag" data-flag="' . esc_attr((string) $target['code']) . '" aria-hidden="true">' . self::flag_markup((string) $target['code']) . '<span class="m360-language-flag-fallback">' . esc_html((string) $target['flag']) . '</span></span>'
            . '<span class="m360-lang-toggle__code">' . esc_html((string) $target['code']) . '</span>'
            . '</a></div>';
    }

    public static function render_navigation(array $atts = []): string
    {
        $target = self::target(true);
        if (!$target['available']) { return ''; }
        $current = self::current_language();
        $active_label = $current['code'] === 'EN' ? 'English' : 'Português';
        $aria_label = $current['code'] === 'EN'
            ? sprintf('Current language: %s. %s', $active_label, (string) $target['aria_label'])
            : sprintf('Idioma atual: %s. %s', $active_label, (string) $target['aria_label']);
        return '<div class="m360-language-navigation" data-m360-language-navigation>'
            . '<a class="m360-language-navigation__link" href="' . esc_url((string) $target['url']) . '" hreflang="' . esc_attr((string) $target['locale']) . '" title="' . esc_attr((string) $target['title']) . '" aria-label="' . esc_attr($aria_label) . '">'
            . '<span class="m360-language-navigation__flag" data-flag="' . esc_attr((string) $target['code']) . '" aria-hidden="true">' . self::flag_markup((string) $target['code']) . '<span class="m360-language-flag-fallback">' . esc_html((string) $target['flag']) . '</span></span>'
            . '<span class="m360-language-navigation__code">' . esc_html((string) $target['code']) . '</span>'
            . '<span class="m360-language-navigation__arrow" aria-hidden="true">↔</span>'
            . '</a></div>';
    }

    private static function current_language(): array
    {
        $slug = function_exists('pll_current_language') ? strtolower((string) pll_current_language('slug')) : '';
        $is_en = str_starts_with($slug, 'en');
        return ['code' => $is_en ? 'EN' : 'PT', 'flag' => $is_en ? '🇺🇸' : '🇧🇷'];
    }

    private static function flag_markup(string $code): string
    {
        if (strtoupper($code) === 'EN') {
            return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21 14" role="presentation" focusable="false" aria-hidden="true"><rect width="21" height="14" fill="#fff"/><path d="M0 1h21M0 3h21M0 5h21M0 7h21M0 9h21M0 11h21M0 13h21" stroke="#c8102e" stroke-width="1"/><rect width="9" height="7.5" fill="#1b3f8b"/><path d="M0 0l9 7.5M9 0L0 7.5" stroke="#fff" stroke-width="1.4"/><path d="M4.5 0v7.5M0 3.75h9" stroke="#c8102e" stroke-width="1"/></svg>';
        }
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21 14" role="presentation" focusable="false" aria-hidden="true"><rect width="21" height="14" fill="#009b3a"/><path d="M10.5 1.2L19.7 7l-9.2 5.8L1.3 7z" fill="#ffdf00"/><circle cx="10.5" cy="7" r="3.2" fill="#143d8d"/></svg>';
    }

    private static function target(bool $allow_home_fallback = false): array
    {
        $empty = [
            'available' => false,
            'url' => '',
            'locale' => '',
            'code' => '',
            'flag' => '',
            'title' => '',
            'aria_label' => '',
        ];

        if (!function_exists('pll_current_language')) { return $empty; }

        $current = strtolower((string) pll_current_language('slug'));
        $target_slug = str_starts_with($current, 'en') ? 'pt' : 'en';
        $url = '';

        if (is_singular()) {
            if (function_exists('pll_get_post')) {
                $translated_id = (int) pll_get_post((int) get_queried_object_id(), $target_slug);
                if ($translated_id > 0 && get_post_status($translated_id) === 'publish') {
                    $url = (string) get_permalink($translated_id);
                }
            }
            if ($url === '' && !$allow_home_fallback) { return $empty; }
        } elseif ((is_category() || is_tag() || is_tax()) && function_exists('pll_get_term')) {
            $term = get_queried_object();
            if ($term instanceof WP_Term) {
                $translated_id = (int) pll_get_term((int) $term->term_id, $target_slug);
                if ($translated_id > 0) {
                    $translated = get_term($translated_id, $term->taxonomy);
                    if ($translated instanceof WP_Term) {
                        $term_link = get_term_link($translated);
                        if (!is_wp_error($term_link)) { $url = (string) $term_link; }
                    }
                }
            }
        } elseif (function_exists('pll_the_languages')) {
            $languages = pll_the_languages(['raw' => 1, 'hide_if_empty' => 0]);
            if (is_array($languages)) {
                foreach ($languages as $language) {
                    if (!is_array($language) || (string) ($language['slug'] ?? '') !== $target_slug) { continue; }
                    $url = (string) ($language['url'] ?? '');
                    break;
                }
            }
        }

        if ($url === '' && ($allow_home_fallback || !is_singular()) && function_exists('pll_home_url')) {
            $url = (string) pll_home_url($target_slug);
        }
        if ($url === '') { return $empty; }

        $is_en_target = $target_slug === 'en';
        return [
            'available' => true,
            'url' => $url,
            'locale' => $is_en_target ? 'en-US' : 'pt-BR',
            'code' => $is_en_target ? 'EN' : 'PT',
            'flag' => $is_en_target ? '🇺🇸' : '🇧🇷',
            'title' => $is_en_target ? 'English' : 'Português',
            'aria_label' => $is_en_target ? 'Switch language to English' : 'Trocar idioma para português',
        ];
    }
}
