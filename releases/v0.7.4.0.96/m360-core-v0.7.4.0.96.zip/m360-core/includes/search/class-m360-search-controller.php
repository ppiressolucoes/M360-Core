<?php
if (!defined('ABSPATH')) { exit; }

final class M360_Search_Controller
{
    public static function register_shortcodes(): void
    {
        add_shortcode('m360_search_results', [self::class, 'shortcode']);
    }

    public static function shortcode(array $atts = []): string
    {
        if (!is_search() || is_admin()) { return ''; }
        return self::render(false);
    }

    public static function restrict_to_language(WP_Query $query): void
    {
        if (is_admin() || !$query->is_main_query() || !$query->is_search() || !function_exists('pll_current_language')) { return; }
        $language = sanitize_key((string) pll_current_language('slug'));
        if ($language !== '') { $query->set('lang', $language); }
    }

    public static function redirect_theme_search(): void
    {
        if (is_admin() || strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') { return; }
        $raw_query = $_GET['m360q'] ?? null;
        if (!is_scalar($raw_query)) { return; }
        $term = trim(sanitize_text_field(wp_unslash((string) $raw_query)));
        if ($term === '') { return; }
        $language = function_exists('pll_current_language') ? sanitize_key((string) pll_current_language('slug')) : '';
        $home = M360_Search_Form_Component::action_url($language);
        $parameters = ['s' => $term];
        if ($language !== '') { $parameters['lang'] = $language; }
        wp_safe_redirect(add_query_arg($parameters, $home), 302);
        exit;
    }

    public static function template_include(string $template): string
    {
        if (!is_search() || is_admin()) { return $template; }
        $m360_template = M360_CORE_PATH . 'templates/search.php';
        return is_readable($m360_template) ? $m360_template : $template;
    }

    public static function render(bool $include_form = true): string
    {
        self::enqueue_assets();
        $query = get_search_query(false);
        $is_en = self::is_en();
        $title = $is_en ? 'Search results' : 'Resultados da pesquisa';
        $empty_title = $is_en ? 'No results found' : 'Nenhum resultado encontrado';
        $empty_text = $is_en ? 'Try searching again with different keywords.' : 'Tente pesquisar novamente com outros termos.';

        ob_start();
        echo '<main class="m360-dynamic-view m360-search-view"><div class="m360-dynamic-view__container">';
        echo do_shortcode('[m360_breadcrumb]');
        $site_name = class_exists('M360_Site_Profile') ? (string) (M360_Site_Profile::get()['site_name'] ?? '') : '';
        if ($site_name === '') { $site_name = (string) get_bloginfo('name'); }
        echo '<header class="m360-search-view__header"><span class="m360-search-view__eyebrow">' . esc_html($is_en ? $site_name . ' Search' : 'Busca ' . $site_name) . '</span><h1>' . esc_html($title) . '</h1><p>' . esc_html($is_en ? 'Search term:' : 'Termo pesquisado:') . ' <strong>' . esc_html($query) . '</strong></p>' . ($include_form ? do_shortcode('[m360_search_form variant="compact" show_intro="false"]') : '') . '</header>';

        if (have_posts()) {
            echo '<section class="m360-search-results" aria-label="' . esc_attr($title) . '">';
            $index = 0;
            while (have_posts()) {
                the_post();
                $index++;
                echo self::render_card();
                echo M360_Ads_Archive_Engine::after_item('search', $index);
            }
            echo '</section>' . self::pagination();
        } else {
            echo '<section class="m360-search-empty"><h2>' . esc_html($empty_title) . '</h2><p>' . esc_html($empty_text) . '</p>';
            echo do_shortcode('[m360_search_form variant="hero"]');
            echo M360_Ads_Archive_Engine::empty_state('search');
            echo '</section>';
        }

        echo '</div></main>';
        wp_reset_postdata();
        return (string) ob_get_clean();
    }

    private static function render_card(): string
    {
        $primary_category = M360_Latest_News_Component::primary_category((int) get_the_ID());
        $category = $primary_category instanceof WP_Term ? $primary_category->name : '';
        $excerpt = get_the_excerpt();
        if ($excerpt === '') { $excerpt = wp_trim_words(wp_strip_all_tags((string) get_the_content()), 26); }
        ob_start();
        echo '<article class="m360-search-card">';
        if (has_post_thumbnail()) { echo '<a class="m360-search-card__thumb" href="' . esc_url(get_permalink()) . '">'; the_post_thumbnail('medium_large'); echo '</a>'; }
        echo '<div class="m360-search-card__body">';
        if ($category !== '') { echo '<span class="m360-search-card__category">' . esc_html($category) . '</span>'; }
        echo '<h2><a href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a></h2><time datetime="' . esc_attr(get_the_date('c')) . '">' . esc_html(get_the_date()) . '</time><p>' . esc_html($excerpt) . '</p></div></article>';
        return (string) ob_get_clean();
    }

    private static function pagination(): string
    {
        $links = paginate_links(['type'=>'list','prev_text'=>self::is_en() ? 'Previous' : 'Anterior','next_text'=>self::is_en() ? 'Next' : 'Próxima']);
        return is_string($links) && $links !== '' ? '<nav class="m360-search-pagination">' . $links . '</nav>' : '';
    }

    private static function enqueue_assets(): void
    {
        if (wp_style_is('m360-core-search', 'registered')) { wp_enqueue_style('m360-core-search'); }
        if (wp_style_is('m360-core-foundation', 'registered')) { wp_enqueue_style('m360-core-foundation'); }
    }

    private static function is_en(): bool
    {
        if (function_exists('pll_current_language')) {
            $language = pll_current_language('slug');
            if (is_string($language) && $language !== '') { return strtolower($language) === 'en'; }
        }
        return str_starts_with((string) determine_locale(), 'en');
    }
}
