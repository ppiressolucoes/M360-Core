(function () {
    'use strict';

    function initStickyNavigation(target) {
        if (!target) { return; }
        if (target.getAttribute('data-m360-sticky-managed') === 'true') { return; }

        target.setAttribute('data-m360-sticky-managed', 'true');
        target.classList.add('m360-core-sticky-target');

        var placeholder = document.createElement('div');
        placeholder.className = 'm360-core-sticky-placeholder';
        placeholder.setAttribute('aria-hidden', 'true');
        target.parentNode.insertBefore(placeholder, target);

        var threshold = 0;
        var ticking = false;

        function adminOffset() {
            var adminBar = document.getElementById('wpadminbar');
            return adminBar ? adminBar.getBoundingClientRect().height : 0;
        }

        function measure() {
            if (!target.classList.contains('m360-is-fixed')) {
                threshold = target.getBoundingClientRect().top + window.scrollY;
                placeholder.style.height = '0px';
            }
        }

        function update() {
            ticking = false;
            var shouldFix = window.scrollY + adminOffset() >= threshold;
            target.classList.toggle('m360-is-fixed', shouldFix);
            target.style.setProperty('--m360-sticky-admin-offset', adminOffset() + 'px');
            if (target.classList.contains('m360-header-navigation-bar')) {
                if (shouldFix) {
                    target.style.setProperty('width', '100%');
                    target.style.setProperty('max-width', '1140px');
                    target.style.setProperty('left', '50%');
                    target.style.setProperty('right', 'auto');
                    target.style.setProperty('transform', 'translateX(-50%)');
                } else {
                    target.style.removeProperty('width');
                    target.style.removeProperty('max-width');
                    target.style.removeProperty('left');
                    target.style.removeProperty('right');
                    target.style.removeProperty('transform');
                }
            }
            placeholder.style.height = shouldFix ? target.getBoundingClientRect().height + 'px' : '0px';
        }

        function requestUpdate() {
            if (ticking) { return; }
            ticking = true;
            window.requestAnimationFrame(update);
        }

        measure();
        update();
        window.addEventListener('scroll', requestUpdate, { passive: true });
        window.addEventListener('resize', function () {
            target.classList.remove('m360-is-fixed');
            measure();
            requestUpdate();
        });
    }

    function initMobileNavigation(shell) {
        if (!shell || shell.getAttribute('data-m360-mobile-nav-managed') === 'true') { return; }

        var toggle = shell.querySelector('.m360-mobile-nav-toggle');
        var button = shell.querySelector('.m360-mobile-nav-button');
        var navigation = shell.querySelector('.m360-main-navigation');
        if (!toggle || !button || !navigation) { return; }

        shell.setAttribute('data-m360-mobile-nav-managed', 'true');
        var ticking = false;

        function isMobile() {
            return window.matchMedia('(max-width: 1024px)').matches;
        }

        function updatePosition() {
            ticking = false;
            button.setAttribute('aria-expanded', toggle.checked ? 'true' : 'false');

            if (!isMobile() || !toggle.checked) {
                navigation.style.removeProperty('--m360-mobile-nav-top');
                return;
            }

            var header = shell.closest('.m360-header-topbar') || shell;
            var top = Math.max(0, Math.min(window.innerHeight, header.getBoundingClientRect().bottom));
            navigation.style.setProperty('--m360-mobile-nav-top', Math.round(top) + 'px');
        }

        function requestPositionUpdate() {
            if (ticking) { return; }
            ticking = true;
            window.requestAnimationFrame(updatePosition);
        }

        button.addEventListener('click', function (event) {
            event.preventDefault();
            toggle.checked = !toggle.checked;
            updatePosition();
        });

        navigation.querySelectorAll('li.menu-item-has-children > a, li.page_item_has_children > a').forEach(function (link) {
            var item = link.parentElement;
            var submenu = item ? item.querySelector(':scope > .sub-menu') : null;
            if (!item || !submenu) { return; }
            link.setAttribute('aria-haspopup', 'true');
            link.setAttribute('aria-expanded', 'false');
            link.addEventListener('click', function (event) {
                if (!isMobile()) { return; }
                var open = link.getAttribute('aria-expanded') === 'true';
                if (!open) {
                    event.preventDefault();
                    navigation.querySelectorAll('li.m360-submenu-open').forEach(function (other) {
                        if (other === item) { return; }
                        other.classList.remove('m360-submenu-open');
                        var otherLink = other.querySelector(':scope > a');
                        if (otherLink) { otherLink.setAttribute('aria-expanded', 'false'); }
                    });
                    item.classList.add('m360-submenu-open');
                    link.setAttribute('aria-expanded', 'true');
                } else {
                    item.classList.remove('m360-submenu-open');
                    link.setAttribute('aria-expanded', 'false');
                }
            });
        });

        toggle.addEventListener('change', updatePosition);
        window.addEventListener('scroll', requestPositionUpdate, { passive: true });
        window.addEventListener('resize', function () {
            if (!isMobile()) {
                toggle.checked = false;
                navigation.querySelectorAll('li.m360-submenu-open').forEach(function (item) { item.classList.remove('m360-submenu-open'); });
                navigation.querySelectorAll('li.menu-item-has-children > a, li.page_item_has_children > a').forEach(function (link) { link.setAttribute('aria-expanded', 'false'); });
            }
            requestPositionUpdate();
        });
        document.addEventListener('click', function (event) {
            if (toggle.checked && !shell.contains(event.target)) {
                toggle.checked = false;
                updatePosition();
            }
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && toggle.checked) {
                toggle.checked = false;
                updatePosition();
                button.focus();
            }
        });

        updatePosition();
    }

    function initDesktopSubmenuAlignment(shell) {
        if (!shell || shell.getAttribute('data-m360-submenu-alignment-managed') === 'true') { return; }
        shell.setAttribute('data-m360-submenu-alignment-managed', 'true');

        var items = shell.querySelectorAll('.m360-main-navigation__menu > li > .sub-menu');
        if (!items.length) { return; }

        function align(item, submenu) {
            if (window.matchMedia('(max-width: 1024px)').matches) {
                item.classList.remove('m360-submenu-align-end');
                return;
            }

            item.classList.remove('m360-submenu-align-end');
            if (submenu.getBoundingClientRect().right > window.innerWidth - 12) {
                item.classList.add('m360-submenu-align-end');
            }
        }

        items.forEach(function (submenu) {
            var item = submenu.parentElement;
            if (!item) { return; }
            item.addEventListener('mouseenter', function () {
                window.requestAnimationFrame(function () { align(item, submenu); });
            });
            item.addEventListener('focusin', function () {
                window.requestAnimationFrame(function () { align(item, submenu); });
            });
        });

        window.addEventListener('resize', function () {
            items.forEach(function (submenu) {
                var item = submenu.parentElement;
                if (item && (item.matches(':hover') || item.contains(document.activeElement))) {
                    align(item, submenu);
                }
            });
        });
    }

    function init() {
        document.querySelectorAll('.m360-header-navigation-bar').forEach(initStickyNavigation);
        document.querySelectorAll('.m360-header-topbar').forEach(function (target) {
            if (!target.querySelector('.m360-navigation-shell.m360-ui-nav, .m360-header-navigation-bar')) { initStickyNavigation(target); }
        });
        document.querySelectorAll('.m360-navigation-shell.m360-ui-nav').forEach(function (shell) {
            if (shell.closest('.m360-header-navigation-bar')) { return; }
            var target = shell.closest('.elementor-top-section, .elementor-section, .elementor-container');
            if (!target || !target.querySelector('.m360-language-navigation, .m360-lang-toggle, .m360-search-form, .m360-search-toggle')) {
                target = shell;
            }
            initStickyNavigation(target);
        });
        document.querySelectorAll('.m360-navigation-shell').forEach(initMobileNavigation);
        document.querySelectorAll('.m360-navigation-shell.m360-ui-nav').forEach(initDesktopSubmenuAlignment);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
}());
