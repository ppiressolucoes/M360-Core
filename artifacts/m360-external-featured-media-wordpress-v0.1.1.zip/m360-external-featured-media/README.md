# M360 External Featured Media — piloto

Plugin WordPress independente para a POC de Featured Images externas no Mengão 360. Ele não grava o binário da imagem no `uploads`: cria um attachment técnico com a URL Cloudinary e expõe endpoints REST para o workflow n8n.

Versão `0.1.1`: durante o piloto PT-BR, a associação ao post também espelha os campos editoriais nos campos nativos do attachment para compatibilidade com o widget de imagem do Elementor. Os metadados do post continuam sendo a fonte de verdade; a etapa EN-US exigirá a camada de apresentação por idioma antes de reutilizar esse fallback global.

## Instalação em homologação

1. Compactar a pasta `m360-external-featured-media` em ZIP e instalar como plugin.
2. Ativar o plugin.
3. Usar um usuário WordPress dedicado com Application Password e as capacidades `upload_files` e `edit_posts` no n8n.
4. Não ativar em produção antes da POC completa.

## Endpoints

### Registrar ou reutilizar mídia

`POST /wp-json/m360/v1/external-featured-media`

Body JSON:

```json
{
  "sha256": "<64-hex>",
  "asset_id": "<cloudinary-asset-id>",
  "public_id": "m360/featured/<hash>",
  "secure_url": "https://res.cloudinary.com/...",
  "width": 1200,
  "height": 675,
  "mime_type": "image/jpeg",
  "original_filename": "imagem.jpg"
}
```

Retorna `attachment_id` e `existing`. Uma repetição com o mesmo hash devolve o attachment já criado.

### Associar ao post PT-BR

`POST /wp-json/m360/v1/external-featured-media/assign`

Body JSON:

```json
{
  "post_id": 123,
  "attachment_id": 456,
  "alt": "...",
  "title": "...",
  "description": "...",
  "caption": "..."
}
```

O endpoint atualiza `_thumbnail_id` e guarda os quatro campos editoriais no post. O attachment é compartilhável para futura tradução EN-US, sem duplicar o arquivo.
